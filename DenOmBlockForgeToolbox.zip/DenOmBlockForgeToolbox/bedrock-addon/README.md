# DenOm BlockForge Bedrock Add-on

## Contents

- `behavior_packs/DenOmBlockForgeBP/` – Script API bridge
  - `manifest.json`
  - `scripts/main.js` – capability handshake + operation handlers
- `resource_packs/DenOmBlockForgeRP/` – optional empty resource pack

## Installation

1. Copy the behavior pack (and optionally the resource pack) into your Minecraft Bedrock world’s `behavior_packs` / `resource_packs` folders **or** import via the in-game Settings → Storage.
2. Enable the pack(s) for the world.
3. Enable **Beta APIs** / **Holiday Creator Features** if required by your Minecraft version for `@minecraft/server`.
4. Join the world. The bridge logs to the content log on startup.

## Protocol

The Android app speaks a JSON protocol (see `BridgeProtocol.kt`).

### Handshake

```json
{
  "type": "Handshake",
  "payload": {
    "clientId": "com.denom.blockforgetoolbox",
    "clientVersion": "1.0.0",
    "protocolVersion": 1
  }
}
```

Response:

```json
{
  "type": "HandshakeAck",
  "payload": {
    "accepted": true,
    "bridgeVersion": "1.0.0",
    "minecraftVersion": "1.20+",
    "authorized": true,
    "capabilities": ["player.teleport", "chat.send", ...],
    "message": "Handshake OK"
  }
}
```

### Operation

```json
{
  "type": "Operation",
  "payload": {
    "requestId": "uuid",
    "capabilityId": "chat.send",
    "parameters": { "message": "hello" }
  }
}
```

Response codes include: `SUCCESS`, `PERMISSION_DENIED`, `UNSUPPORTED`, `INVALID_PARAMS`, `EXECUTION_ERROR`, `NOT_CONNECTED`, etc.

## Chat-command fallback

When a pure WebSocket server is unavailable inside the Script API runtime:

```
!bf handshake
!bf op chat.send message=Hello
!bf op player.teleport x=0 y=80 z=0
```

Operators only. Non-operators receive `PERMISSION_DENIED`.

## Security

- No credentials are collected.
- Authorization is derived from operator / host status inside the world.
- The Android app never invents success responses; every result comes from the bridge.
