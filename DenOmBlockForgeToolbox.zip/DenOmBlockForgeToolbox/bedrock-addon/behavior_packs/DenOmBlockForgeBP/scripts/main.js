/**
 * DenOm BlockForge Bridge
 *
 * Runs inside Minecraft Bedrock as a Script API module.
 * Uses @minecraft/server and (where available) @minecraft/server-net
 * to expose a local WebSocket-style endpoint that the Android app connects to.
 *
 * IMPORTANT:
 * - We only use documented Script API surfaces.
 * - Authorization is controlled by the world host / operator status.
 * - No credentials are ever requested or stored.
 * - Operations that are not supported return explicit UNSUPPORTED / PERMISSION_DENIED.
 *
 * Note: Full WebSocket server support depends on the experimental @minecraft/server-net
 * module and the host environment. When the net module is unavailable the bridge
 * still performs an in-memory capability handshake so the Android diagnostics
 * path can report accurate states.
 */

import { system, world, Player, GameMode } from "@minecraft/server";

// ---------------------------------------------------------------------------
// Configuration
// ---------------------------------------------------------------------------
const BRIDGE_VERSION = "1.0.0";
const PROTOCOL_VERSION = 1;
const CLIENT_ID = "com.denom.blockforgetoolbox";

/** Capabilities this bridge is willing to advertise when the caller is authorized. */
const ADVERTISED_CAPABILITIES = [
  "player.teleport",
  "player.set_game_mode",
  "world.set_block",
  "world.fill",
  "entity.summon",
  "world.time_set",
  "world.weather_set",
  "chat.send"
];

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
let authorized = false;
let lastClientId = null;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
function log(msg) {
  console.warn(`[BlockForge] ${msg}`);
}

function isOperator(player) {
  // In Bedrock Script API, permission level is not always exposed the same way
  // across versions. We treat the first player that enables the bridge as the
  // authorizing host for local single-player / LAN sessions.
  try {
    return player && typeof player.isOp === "function" ? player.isOp() : true;
  } catch (_) {
    return true; // local single-player fallback
  }
}

function makeResult(requestId, capabilityId, success, code, message, data = {}) {
  return {
    type: "OperationAck",
    payload: {
      requestId,
      capabilityId,
      success,
      code,
      message,
      data
    }
  };
}

// ---------------------------------------------------------------------------
// Operation handlers (real Script API calls)
// ---------------------------------------------------------------------------
function handlePlayerTeleport(params, sourcePlayer) {
  const x = Number(params.x);
  const y = Number(params.y);
  const z = Number(params.z);
  if (Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(z)) {
    return { success: false, code: "INVALID_PARAMS", message: "x,y,z required" };
  }
  try {
    const target = sourcePlayer || world.getAllPlayers()[0];
    if (!target) {
      return { success: false, code: "NO_PLAYER", message: "No player available" };
    }
    target.teleport({ x, y, z });
    return { success: true, code: "SUCCESS", message: `Teleported to ${x},${y},${z}` };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

function handleSetGameMode(params, sourcePlayer) {
  const mode = (params.mode || "").toLowerCase();
  const map = {
    survival: GameMode.survival,
    creative: GameMode.creative,
    adventure: GameMode.adventure,
    spectator: GameMode.spectator
  };
  if (!map[mode]) {
    return { success: false, code: "INVALID_PARAMS", message: "mode must be survival|creative|adventure|spectator" };
  }
  try {
    const target = sourcePlayer || world.getAllPlayers()[0];
    if (!target) {
      return { success: false, code: "NO_PLAYER", message: "No player available" };
    }
    target.setGameMode(map[mode]);
    return { success: true, code: "SUCCESS", message: `GameMode set to ${mode}` };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

function handleSetBlock(params) {
  const x = Number(params.x);
  const y = Number(params.y);
  const z = Number(params.z);
  const typeId = params.block || "minecraft:stone";
  if (Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(z)) {
    return { success: false, code: "INVALID_PARAMS", message: "x,y,z required" };
  }
  try {
    const dim = world.getDimension("overworld");
    dim.setBlockType({ x, y, z }, typeId);
    return { success: true, code: "SUCCESS", message: `Set ${typeId} at ${x},${y},${z}` };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

function handleFill(params) {
  // Simplified: fill is not a single API call; we iterate a small volume.
  const x1 = Number(params.x1), y1 = Number(params.y1), z1 = Number(params.z1);
  const x2 = Number(params.x2), y2 = Number(params.y2), z2 = Number(params.z2);
  const typeId = params.block || "minecraft:stone";
  if ([x1, y1, z1, x2, y2, z2].some(Number.isNaN)) {
    return { success: false, code: "INVALID_PARAMS", message: "x1,y1,z1,x2,y2,z2 required" };
  }
  try {
    const dim = world.getDimension("overworld");
    const minX = Math.min(x1, x2), maxX = Math.max(x1, x2);
    const minY = Math.min(y1, y2), maxY = Math.max(y1, y2);
    const minZ = Math.min(z1, z2), maxZ = Math.max(z1, z2);
    // Hard safety limit
    if ((maxX - minX + 1) * (maxY - minY + 1) * (maxZ - minZ + 1) > 4096) {
      return { success: false, code: "VOLUME_TOO_LARGE", message: "Max volume 4096 blocks" };
    }
    for (let x = minX; x <= maxX; x++) {
      for (let y = minY; y <= maxY; y++) {
        for (let z = minZ; z <= maxZ; z++) {
          dim.setBlockType({ x, y, z }, typeId);
        }
      }
    }
    return { success: true, code: "SUCCESS", message: "Fill completed" };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

function handleSummon(params) {
  const typeId = params.type || "minecraft:pig";
  const x = Number(params.x), y = Number(params.y), z = Number(params.z);
  if (Number.isNaN(x) || Number.isNaN(y) || Number.isNaN(z)) {
    return { success: false, code: "INVALID_PARAMS", message: "x,y,z required" };
  }
  try {
    const dim = world.getDimension("overworld");
    dim.spawnEntity(typeId, { x, y, z });
    return { success: true, code: "SUCCESS", message: `Summoned ${typeId}` };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

function handleTimeSet(params) {
  const time = Number(params.time);
  if (Number.isNaN(time)) {
    return { success: false, code: "INVALID_PARAMS", message: "time (0-24000) required" };
  }
  try {
    world.setTimeOfDay(time);
    return { success: true, code: "SUCCESS", message: `Time set to ${time}` };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

function handleWeatherSet(params) {
  const weather = (params.weather || "").toLowerCase();
  try {
    // Script API weather control varies by version; use setWeather when present.
    if (typeof world.setWeather === "function") {
      world.setWeather(weather);
      return { success: true, code: "SUCCESS", message: `Weather set to ${weather}` };
    }
    return { success: false, code: "UNSUPPORTED", message: "setWeather not available in this runtime" };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

function handleChatSend(params) {
  const message = params.message || "";
  try {
    world.sendMessage(`[BlockForge] ${message}`);
    return { success: true, code: "SUCCESS", message: "Message sent" };
  } catch (e) {
    return { success: false, code: "EXECUTION_ERROR", message: String(e) };
  }
}

const HANDLERS = {
  "player.teleport": handlePlayerTeleport,
  "player.set_game_mode": handleSetGameMode,
  "world.set_block": handleSetBlock,
  "world.fill": handleFill,
  "entity.summon": handleSummon,
  "world.time_set": handleTimeSet,
  "world.weather_set": handleWeatherSet,
  "chat.send": handleChatSend
};

// ---------------------------------------------------------------------------
// Message processing (shared by net or in-memory path)
// ---------------------------------------------------------------------------
function processMessage(raw, replyFn, sourcePlayer) {
  let msg;
  try {
    msg = typeof raw === "string" ? JSON.parse(raw) : raw;
  } catch (e) {
    replyFn({ type: "Error", code: "PARSE_ERROR", message: String(e) });
    return;
  }

  const type = msg.type;
  if (type === "Handshake") {
    const payload = msg.payload || {};
    lastClientId = payload.clientId || null;
    const accepted = payload.clientId === CLIENT_ID || !payload.clientId;
    // Authorization: only operators / host may authorize the bridge.
    authorized = accepted && (sourcePlayer ? isOperator(sourcePlayer) : true);
    const response = {
      type: "HandshakeAck",
      payload: {
        accepted,
        bridgeVersion: BRIDGE_VERSION,
        minecraftVersion: "1.20+",
        authorized,
        capabilities: authorized ? ADVERTISED_CAPABILITIES : [],
        message: authorized ? "Handshake OK" : "Not authorized (operator required)"
      }
    };
    replyFn(response);
    log(`Handshake from ${lastClientId}: accepted=${accepted}, authorized=${authorized}`);
    return;
  }

  if (type === "Operation") {
    const op = msg.payload || {};
    const requestId = op.requestId || "unknown";
    const capabilityId = op.capabilityId || "";
    const parameters = op.parameters || {};

    if (!authorized) {
      replyFn(makeResult(requestId, capabilityId, false, "PERMISSION_DENIED", "Not authorized"));
      return;
    }
    const handler = HANDLERS[capabilityId];
    if (!handler) {
      replyFn(makeResult(requestId, capabilityId, false, "UNSUPPORTED", "Capability not implemented"));
      return;
    }
    const result = handler(parameters, sourcePlayer);
    replyFn(makeResult(requestId, capabilityId, result.success, result.code, result.message, result.data || {}));
    return;
  }

  if (type === "Ping") {
    replyFn({ type: "Pong", ts: Date.now() });
    return;
  }

  replyFn({ type: "Error", code: "UNKNOWN_TYPE", message: `Unknown message type: ${type}` });
}

// ---------------------------------------------------------------------------
// Optional @minecraft/server-net WebSocket server
// ---------------------------------------------------------------------------
async function tryStartNetServer() {
  try {
    // Dynamic import so the pack still loads when the net module is absent.
    const net = await import("@minecraft/server-net");
    if (!net || !net.HttpRequest) {
      log("server-net module present but WebSocket server API not available; using chat-command fallback");
      return false;
    }
    // As of current documented APIs, a full bidirectional WebSocket server
    // is still experimental / limited. We document the expected endpoint
    // and fall back to the chat-command path for reliability.
    log("server-net detected – configure external reverse-proxy if needed (ws://127.0.0.1:19134)");
    return false;
  } catch (e) {
    log("server-net not available – using chat-command / event fallback");
    return false;
  }
}

// ---------------------------------------------------------------------------
// Chat-command fallback (always available)
// ---------------------------------------------------------------------------
// Players (operators) can drive the bridge with:
//   !bf handshake
//   !bf op <capabilityId> key=value ...
// The Android app can also be pointed at a local TCP/WS proxy that translates
// these chat commands if a pure in-game WS server is unavailable.

world.beforeEvents.chatSend.subscribe((event) => {
  const msg = event.message;
  if (!msg.startsWith("!bf ")) return;
  event.cancel = true;
  const player = event.sender;
  const parts = msg.slice(4).trim().split(/\s+/);
  const cmd = parts[0];

  const reply = (obj) => {
    try {
      player.sendMessage(JSON.stringify(obj));
    } catch (_) {
      log(JSON.stringify(obj));
    }
  };

  if (cmd === "handshake") {
    processMessage(
      { type: "Handshake", payload: { clientId: CLIENT_ID, clientVersion: "1.0.0", protocolVersion: 1 } },
      reply,
      player
    );
    return;
  }

  if (cmd === "op") {
    const capabilityId = parts[1];
    const parameters = {};
    for (let i = 2; i < parts.length; i++) {
      const kv = parts[i].split("=");
      if (kv.length === 2) parameters[kv[0]] = kv[1];
    }
    processMessage(
      {
        type: "Operation",
        payload: {
          requestId: `chat-${Date.now()}`,
          capabilityId,
          parameters
        }
      },
      reply,
      player
    );
    return;
  }

  player.sendMessage("BlockForge: unknown command. Use !bf handshake | !bf op <cap> key=val");
});

// ---------------------------------------------------------------------------
// Startup
// ---------------------------------------------------------------------------
system.run(() => {
  log(`DenOm BlockForge Bridge v${BRIDGE_VERSION} starting`);
  tryStartNetServer().then((started) => {
    if (!started) {
      log("Ready – use chat commands (!bf handshake / !bf op ...) or external WS proxy on 19134");
    }
  });
});
