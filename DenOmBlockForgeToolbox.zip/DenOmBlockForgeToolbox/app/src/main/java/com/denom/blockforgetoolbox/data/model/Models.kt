package com.denom.blockforgetoolbox.data.model

import kotlinx.serialization.Serializable

@Serializable
enum class ConnectionState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    ERROR
}

@Serializable
enum class AuthorizationState {
    UNKNOWN,
    UNAUTHORIZED,
    AUTHORIZED,
    REVOKED
}

@Serializable
data class IntegrationStatus(
    val connection: ConnectionState = ConnectionState.DISCONNECTED,
    val authorization: AuthorizationState = AuthorizationState.UNKNOWN,
    val bridgeVersion: String? = null,
    val minecraftVersion: String? = null,
    val lastError: String? = null,
    val supportedCapabilities: List<String> = emptyList()
)

@Serializable
data class OperationRequest(
    val requestId: String,
    val capabilityId: String,
    val parameters: Map<String, String> = emptyMap(),
    val timestamp: Long = System.currentTimeMillis()
)

@Serializable
data class OperationResult(
    val requestId: String,
    val capabilityId: String,
    val success: Boolean,
    val code: String,
    val message: String,
    val data: Map<String, String> = emptyMap()
)

@Serializable
data class HandshakeRequest(
    val clientId: String = "com.denom.blockforgetoolbox",
    val clientVersion: String = "1.0.0",
    val protocolVersion: Int = 1
)

@Serializable
data class HandshakeResponse(
    val accepted: Boolean,
    val bridgeVersion: String,
    val minecraftVersion: String,
    val authorized: Boolean,
    val capabilities: List<String>,
    val message: String? = null
)

@Serializable
sealed class BridgeMessage {
    @Serializable
    data class Handshake(val payload: HandshakeRequest) : BridgeMessage()

    @Serializable
    data class HandshakeAck(val payload: HandshakeResponse) : BridgeMessage()

    @Serializable
    data class Operation(val payload: OperationRequest) : BridgeMessage()

    @Serializable
    data class OperationAck(val payload: OperationResult) : BridgeMessage()

    @Serializable
    data class Error(val code: String, val message: String) : BridgeMessage()

    @Serializable
    data class Ping(val ts: Long = System.currentTimeMillis()) : BridgeMessage()

    @Serializable
    data class Pong(val ts: Long) : BridgeMessage()
}
