package com.denom.blockforgetoolbox.data.repository

import com.denom.blockforgetoolbox.data.model.IntegrationStatus
import com.denom.blockforgetoolbox.data.model.OperationResult
import com.denom.blockforgetoolbox.domain.capability.Capability
import com.denom.blockforgetoolbox.domain.capability.CapabilityState
import com.denom.blockforgetoolbox.domain.capability.CapabilityStatus
import com.denom.blockforgetoolbox.integration.bedrock.BedrockBridgeClient
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IntegrationRepository @Inject constructor(
    private val bridge: BedrockBridgeClient
) {
    val status: StateFlow<IntegrationStatus> = bridge.status
    val operationResults: SharedFlow<OperationResult> = bridge.operationResults

    fun connect(endpoint: String? = null) {
        endpoint?.let { bridge.setEndpoint(it) }
        bridge.connect()
    }

    fun disconnect() {
        bridge.disconnect()
    }

    suspend fun execute(
        capability: Capability,
        parameters: Map<String, String> = emptyMap()
    ): OperationResult {
        return bridge.executeOperation(capability.id, parameters)
    }

    fun capabilityStatuses(): Flow<List<CapabilityStatus>> =
        status.map { s ->
            Capability.entries.map { cap ->
                val state = when {
                    s.connection != com.denom.blockforgetoolbox.data.model.ConnectionState.CONNECTED ->
                        CapabilityState.NOT_CONNECTED
                    s.authorization != com.denom.blockforgetoolbox.data.model.AuthorizationState.AUTHORIZED ->
                        CapabilityState.NOT_AUTHORIZED
                    cap.id !in s.supportedCapabilities ->
                        CapabilityState.UNSUPPORTED
                    else -> CapabilityState.AVAILABLE
                }
                CapabilityStatus(cap, state)
            }
        }
}
