package com.denom.blockforgetoolbox

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class BlockForgeApp : Application()
