package com.denom.blockforgetoolbox.ui.screens.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.denom.blockforgetoolbox.integration.bedrock.BedrockBridgeClient
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val bridge: BedrockBridgeClient
) : ViewModel() {

    private val _endpoint = MutableStateFlow(bridge.endpoint)
    val endpoint: StateFlow<String> = _endpoint.asStateFlow()

    fun updateEndpoint(value: String) {
        _endpoint.value = value
    }

    fun applyEndpoint() {
        viewModelScope.launch {
            bridge.setEndpoint(_endpoint.value.trim())
        }
    }
}
