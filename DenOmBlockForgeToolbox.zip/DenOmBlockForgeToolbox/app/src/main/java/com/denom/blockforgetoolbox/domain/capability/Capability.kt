package com.denom.blockforgetoolbox.domain.capability

/**
 * Canonical capability identifiers exchanged during the handshake
 * with the Bedrock Script API bridge.
 */
enum class Capability(val id: String, val displayName: String, val description: String) {
    PLAYER_TELEPORT(
        id = "player.teleport",
        displayName = "Player Teleport",
        description = "Teleport the local player to coordinates"
    ),
    PLAYER_SET_GAME_MODE(
        id = "player.set_game_mode",
        displayName = "Set Game Mode",
        description = "Change the local player's game mode"
    ),
    WORLD_SET_BLOCK(
        id = "world.set_block",
        displayName = "Set Block",
        description = "Place or replace a block in the world"
    ),
    WORLD_FILL(
        id = "world.fill",
        displayName = "Fill Region",
        description = "Fill a rectangular region with a block"
    ),
    ENTITY_SUMMON(
        id = "entity.summon",
        displayName = "Summon Entity",
        description = "Summon an entity at coordinates"
    ),
    TIME_SET(
        id = "world.time_set",
        displayName = "Set Time",
        description = "Set world time of day"
    ),
    WEATHER_SET(
        id = "world.weather_set",
        displayName = "Set Weather",
        description = "Change weather"
    ),
    MESSAGE_SEND(
        id = "chat.send",
        displayName = "Send Message",
        description = "Send a chat / system message"
    );

    companion object {
        fun fromId(id: String): Capability? = entries.find { it.id == id }
    }
}

enum class CapabilityState {
    AVAILABLE,
    UNSUPPORTED,
    REQUIRES_CONFIGURATION,
    PERMISSION_DENIED,
    NOT_CONNECTED,
    NOT_AUTHORIZED
}

data class CapabilityStatus(
    val capability: Capability,
    val state: CapabilityState,
    val detail: String? = null
)
