package com.denom.blockforgetoolbox.ui.screens.toolbox

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.denom.blockforgetoolbox.domain.capability.Capability
import com.denom.blockforgetoolbox.domain.capability.CapabilityState
import com.denom.blockforgetoolbox.domain.capability.CapabilityStatus

@Composable
fun ToolboxScreen(
    viewModel: ToolboxViewModel = hiltViewModel()
) {
    val capabilities by viewModel.capabilities.collectAsState()
    val lastResult by viewModel.lastResult.collectAsState()
    val isExecuting by viewModel.isExecuting.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Toolbox",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Capabilities are gated by connection + authorization + bridge advertisement.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(12.dp))

        if (lastResult != null) {
            ResultCard(result = lastResult!!, onDismiss = { viewModel.clearResult() })
            Spacer(Modifier.height(12.dp))
        }

        if (isExecuting) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                CircularProgressIndicator()
            }
            Spacer(Modifier.height(8.dp))
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(capabilities, key = { it.capability.id }) { status ->
                CapabilityCard(
                    status = status,
                    enabled = status.state == CapabilityState.AVAILABLE && !isExecuting,
                    onExecute = { viewModel.execute(status.capability) }
                )
            }
        }
    }
}

@Composable
private fun CapabilityCard(
    status: CapabilityStatus,
    enabled: Boolean,
    onExecute: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (status.state) {
                CapabilityState.AVAILABLE -> MaterialTheme.colorScheme.primaryContainer
                CapabilityState.UNSUPPORTED -> MaterialTheme.colorScheme.surfaceVariant
                CapabilityState.PERMISSION_DENIED,
                CapabilityState.NOT_AUTHORIZED -> MaterialTheme.colorScheme.errorContainer
                else -> MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                status.capability.displayName,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                status.capability.description,
                style = MaterialTheme.typography.bodySmall
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "State: ${status.state.name}",
                style = MaterialTheme.typography.labelLarge
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = onExecute,
                enabled = enabled
            ) {
                Text("Execute")
            }
        }
    }
}

@Composable
private fun ResultCard(
    result: com.denom.blockforgetoolbox.data.model.OperationResult,
    onDismiss: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = if (result.success)
                MaterialTheme.colorScheme.primaryContainer
            else
                MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(
                if (result.success) "SUCCESS" else "FAILED",
                fontWeight = FontWeight.Bold
            )
            Text("Capability: ${result.capabilityId}")
            Text("Code: ${result.code}")
            Text("Message: ${result.message}")
            Spacer(Modifier.height(8.dp))
            Button(onClick = onDismiss) {
                Text("Dismiss")
            }
        }
    }
}
