package com.denom.blockforgetoolbox.ui.screens.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.denom.blockforgetoolbox.data.model.AuthorizationState
import com.denom.blockforgetoolbox.data.model.ConnectionState

@Composable
fun HomeScreen(
    viewModel: HomeViewModel = hiltViewModel()
) {
    val status by viewModel.status.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "DenOm BlockForge Toolbox",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Minecraft Bedrock integration companion",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(8.dp))

        StatusCard(
            title = "Connection",
            value = status.connection.name,
            isPositive = status.connection == ConnectionState.CONNECTED
        )
        StatusCard(
            title = "Authorization",
            value = status.authorization.name,
            isPositive = status.authorization == AuthorizationState.AUTHORIZED
        )
        if (status.bridgeVersion != null) {
            StatusCard(title = "Bridge Version", value = status.bridgeVersion ?: "—")
        }
        if (status.minecraftVersion != null) {
            StatusCard(title = "Minecraft Version", value = status.minecraftVersion ?: "—")
        }
        if (!status.lastError.isNullOrBlank()) {
            StatusCard(
                title = "Last Error",
                value = status.lastError ?: "",
                isPositive = false
            )
        }

        Spacer(Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { viewModel.onConnect() },
                enabled = status.connection != ConnectionState.CONNECTED &&
                        status.connection != ConnectionState.CONNECTING,
                modifier = Modifier.weight(1f)
            ) {
                Text("Connect")
            }
            OutlinedButton(
                onClick = { viewModel.onDisconnect() },
                enabled = status.connection == ConnectionState.CONNECTED ||
                        status.connection == ConnectionState.ERROR,
                modifier = Modifier.weight(1f)
            ) {
                Text("Disconnect")
            }
        }

        Text(
            text = "Supported capabilities: ${status.supportedCapabilities.size}",
            style = MaterialTheme.typography.bodyLarge
        )
    }
}

@Composable
private fun StatusCard(
    title: String,
    value: String,
    isPositive: Boolean? = null
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when (isPositive) {
                true -> MaterialTheme.colorScheme.primaryContainer
                false -> MaterialTheme.colorScheme.errorContainer
                null -> MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.labelLarge)
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
