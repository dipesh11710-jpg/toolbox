package com.denom.blockforgetoolbox.integration.protocol

import com.denom.blockforgetoolbox.data.model.BridgeMessage
import com.denom.blockforgetoolbox.data.model.HandshakeRequest
import com.denom.blockforgetoolbox.data.model.HandshakeResponse
import com.denom.blockforgetoolbox.data.model.OperationRequest
import com.denom.blockforgetoolbox.data.model.OperationResult
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlinx.serialization.modules.SerializersModule
import kotlinx.serialization.modules.polymorphic
import kotlinx.serialization.modules.subclass

/**
 * JSON protocol used between the Android app and the Bedrock Script API bridge.
 * The bridge runs inside a Minecraft Bedrock world as a behavior pack script
 * and exposes a local WebSocket (or named-pipe style) endpoint.
 */
object BridgeProtocol {

    val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
        classDiscriminator = "type"
        serializersModule = SerializersModule {
            polymorphic(BridgeMessage::class) {
                subclass(BridgeMessage.Handshake::class)
                subclass(BridgeMessage.HandshakeAck::class)
                subclass(BridgeMessage.Operation::class)
                subclass(BridgeMessage.OperationAck::class)
                subclass(BridgeMessage.Error::class)
                subclass(BridgeMessage.Ping::class)
                subclass(BridgeMessage.Pong::class)
            }
        }
    }

    fun encode(message: BridgeMessage): String = json.encodeToString(message)

    fun decode(raw: String): BridgeMessage = json.decodeFromString(raw)

    fun createHandshake(): BridgeMessage.Handshake =
        BridgeMessage.Handshake(HandshakeRequest())

    fun createOperation(
        requestId: String,
        capabilityId: String,
        parameters: Map<String, String>
    ): BridgeMessage.Operation =
        BridgeMessage.Operation(
            OperationRequest(
                requestId = requestId,
                capabilityId = capabilityId,
                parameters = parameters
            )
        )
}
