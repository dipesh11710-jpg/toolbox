package com.denom.blockforgetoolbox.integration.bedrock

import com.denom.blockforgetoolbox.data.model.AuthorizationState
import com.denom.blockforgetoolbox.data.model.BridgeMessage
import com.denom.blockforgetoolbox.data.model.ConnectionState
import com.denom.blockforgetoolbox.data.model.HandshakeResponse
import com.denom.blockforgetoolbox.data.model.IntegrationStatus
import com.denom.blockforgetoolbox.data.model.OperationRequest
import com.denom.blockforgetoolbox.data.model.OperationResult
import com.denom.blockforgetoolbox.integration.protocol.BridgeProtocol
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Real WebSocket client that talks to the Bedrock Script API bridge.
 * Default endpoint: ws://127.0.0.1:19134 (configurable).
 *
 * The bridge itself is implemented as a Minecraft Bedrock behavior pack
 * using the official @minecraft/server Script API (see bedrock-addon/).
 */
@Singleton
class BedrockBridgeClient @Inject constructor() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null
    private var connectJob: Job? = null

    private val _status = MutableStateFlow(IntegrationStatus())
    val status: StateFlow<IntegrationStatus> = _status.asStateFlow()

    private val _operationResults = MutableSharedFlow<OperationResult>(extraBufferCapacity = 32)
    val operationResults: SharedFlow<OperationResult> = _operationResults.asSharedFlow()

    private val pending = ConcurrentHashMap<String, (OperationResult) -> Unit>()

    var endpoint: String = "ws://127.0.0.1:19134"
        private set

    fun setEndpoint(url: String) {
        endpoint = url
    }

    fun connect() {
        if (_status.value.connection == ConnectionState.CONNECTED ||
            _status.value.connection == ConnectionState.CONNECTING
        ) return

        _status.update {
            it.copy(
                connection = ConnectionState.CONNECTING,
                lastError = null
            )
        }

        connectJob?.cancel()
        connectJob = scope.launch {
            try {
                val request = Request.Builder().url(endpoint).build()
                webSocket = client.newWebSocket(request, listener)
            } catch (e: Exception) {
                _status.update {
                    it.copy(
                        connection = ConnectionState.ERROR,
                        lastError = e.message ?: "Connection failed"
                    )
                }
            }
        }
    }

    fun disconnect() {
        connectJob?.cancel()
        webSocket?.close(1000, "Client disconnect")
        webSocket = null
        pending.clear()
        _status.value = IntegrationStatus(
            connection = ConnectionState.DISCONNECTED,
            authorization = AuthorizationState.UNKNOWN
        )
    }

    suspend fun performHandshake(): HandshakeResponse? = withContext(Dispatchers.IO) {
        val ws = webSocket ?: return@withContext null
        val msg = BridgeProtocol.createHandshake()
        ws.send(BridgeProtocol.encode(msg))
        // Response is handled asynchronously in the listener;
        // callers observe status flow.
        null
    }

    suspend fun executeOperation(
        capabilityId: String,
        parameters: Map<String, String> = emptyMap()
    ): OperationResult = withContext(Dispatchers.IO) {
        val current = _status.value
        if (current.connection != ConnectionState.CONNECTED) {
            return@withContext OperationResult(
                requestId = "local",
                capabilityId = capabilityId,
                success = false,
                code = "NOT_CONNECTED",
                message = "Bridge is not connected"
            )
        }
        if (current.authorization != AuthorizationState.AUTHORIZED) {
            return@withContext OperationResult(
                requestId = "local",
                capabilityId = capabilityId,
                success = false,
                code = "PERMISSION_DENIED",
                message = "Not authorized by the Bedrock bridge"
            )
        }
        if (capabilityId !in current.supportedCapabilities) {
            return@withContext OperationResult(
                requestId = "local",
                capabilityId = capabilityId,
                success = false,
                code = "UNSUPPORTED",
                message = "Capability not advertised by bridge"
            )
        }

        val requestId = UUID.randomUUID().toString()
        val request = OperationRequest(
            requestId = requestId,
            capabilityId = capabilityId,
            parameters = parameters
        )

        val resultDeferred = kotlinx.coroutines.CompletableDeferred<OperationResult>()
        pending[requestId] = { resultDeferred.complete(it) }

        val sent = webSocket?.send(
            BridgeProtocol.encode(BridgeMessage.Operation(request))
        ) ?: false

        if (!sent) {
            pending.remove(requestId)
            return@withContext OperationResult(
                requestId = requestId,
                capabilityId = capabilityId,
                success = false,
                code = "SEND_FAILED",
                message = "Failed to send operation to bridge"
            )
        }

        // Wait with timeout
        try {
            kotlinx.coroutines.withTimeout(10_000) {
                resultDeferred.await()
            }
        } catch (e: Exception) {
            pending.remove(requestId)
            OperationResult(
                requestId = requestId,
                capabilityId = capabilityId,
                success = false,
                code = "TIMEOUT",
                message = "Bridge did not respond in time"
            )
        }
    }

    private val listener = object : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            _status.update {
                it.copy(connection = ConnectionState.CONNECTED, lastError = null)
            }
            // Automatically send handshake
            scope.launch {
                delay(100)
                webSocket.send(BridgeProtocol.encode(BridgeProtocol.createHandshake()))
            }
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                when (val msg = BridgeProtocol.decode(text)) {
                    is BridgeMessage.HandshakeAck -> handleHandshake(msg.payload)
                    is BridgeMessage.OperationAck -> handleOperationAck(msg.payload)
                    is BridgeMessage.Error -> {
                        _status.update {
                            it.copy(lastError = "${msg.code}: ${msg.message}")
                        }
                    }
                    is BridgeMessage.Pong -> { /* keep-alive */ }
                    else -> { /* ignore */ }
                }
            } catch (e: Exception) {
                _status.update {
                    it.copy(lastError = "Protocol error: ${e.message}")
                }
            }
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }

        override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
            _status.value = IntegrationStatus(
                connection = ConnectionState.DISCONNECTED,
                authorization = AuthorizationState.UNKNOWN,
                lastError = reason.ifBlank { null }
            )
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            _status.update {
                it.copy(
                    connection = ConnectionState.ERROR,
                    authorization = AuthorizationState.UNKNOWN,
                    lastError = t.message ?: "WebSocket failure"
                )
            }
        }
    }

    private fun handleHandshake(response: HandshakeResponse) {
        _status.update {
            it.copy(
                connection = if (response.accepted) ConnectionState.CONNECTED else ConnectionState.ERROR,
                authorization = if (response.authorized) AuthorizationState.AUTHORIZED
                else AuthorizationState.UNAUTHORIZED,
                bridgeVersion = response.bridgeVersion,
                minecraftVersion = response.minecraftVersion,
                supportedCapabilities = response.capabilities,
                lastError = response.message
            )
        }
    }

    private fun handleOperationAck(result: OperationResult) {
        pending.remove(result.requestId)?.invoke(result)
        scope.launch {
            _operationResults.emit(result)
        }
    }
}
