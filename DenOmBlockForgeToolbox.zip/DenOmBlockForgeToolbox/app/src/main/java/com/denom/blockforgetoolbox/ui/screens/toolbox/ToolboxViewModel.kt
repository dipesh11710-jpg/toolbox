package com.denom.blockforgetoolbox.ui.screens.toolbox

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.denom.blockforgetoolbox.data.model.OperationResult
import com.denom.blockforgetoolbox.domain.capability.Capability
import com.denom.blockforgetoolbox.domain.capability.CapabilityStatus
import com.denom.blockforgetoolbox.domain.usecase.ExecuteCapabilityUseCase
import com.denom.blockforgetoolbox.domain.usecase.ObserveCapabilityStatusesUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ToolboxViewModel @Inject constructor(
    observeCapabilities: ObserveCapabilityStatusesUseCase,
    private val executeCapability: ExecuteCapabilityUseCase
) : ViewModel() {

    val capabilities: StateFlow<List<CapabilityStatus>> = observeCapabilities()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = emptyList()
        )

    private val _lastResult = MutableStateFlow<OperationResult?>(null)
    val lastResult: StateFlow<OperationResult?> = _lastResult.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    fun execute(capability: Capability, parameters: Map<String, String> = emptyMap()) {
        viewModelScope.launch {
            _isExecuting.value = true
            try {
                val result = executeCapability(capability, parameters)
                _lastResult.value = result
            } finally {
                _isExecuting.value = false
            }
        }
    }

    fun clearResult() {
        _lastResult.value = null
    }
}
