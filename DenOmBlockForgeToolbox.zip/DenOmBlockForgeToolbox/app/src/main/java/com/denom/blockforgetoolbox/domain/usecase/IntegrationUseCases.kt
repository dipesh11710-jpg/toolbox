package com.denom.blockforgetoolbox.domain.usecase

import com.denom.blockforgetoolbox.data.model.OperationResult
import com.denom.blockforgetoolbox.data.repository.IntegrationRepository
import com.denom.blockforgetoolbox.domain.capability.Capability
import com.denom.blockforgetoolbox.domain.capability.CapabilityStatus
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ConnectBridgeUseCase @Inject constructor(
    private val repository: IntegrationRepository
) {
    operator fun invoke(endpoint: String? = null) {
        repository.connect(endpoint)
    }
}

class DisconnectBridgeUseCase @Inject constructor(
    private val repository: IntegrationRepository
) {
    operator fun invoke() {
        repository.disconnect()
    }
}

class ExecuteCapabilityUseCase @Inject constructor(
    private val repository: IntegrationRepository
) {
    suspend operator fun invoke(
        capability: Capability,
        parameters: Map<String, String> = emptyMap()
    ): OperationResult {
        return repository.execute(capability, parameters)
    }
}

class ObserveCapabilityStatusesUseCase @Inject constructor(
    private val repository: IntegrationRepository
) {
    operator fun invoke(): Flow<List<CapabilityStatus>> = repository.capabilityStatuses()
}

class ObserveIntegrationStatusUseCase @Inject constructor(
    private val repository: IntegrationRepository
) {
    operator fun invoke() = repository.status
}
