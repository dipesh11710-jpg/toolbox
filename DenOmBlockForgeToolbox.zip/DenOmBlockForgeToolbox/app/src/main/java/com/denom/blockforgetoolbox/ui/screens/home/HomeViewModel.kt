package com.denom.blockforgetoolbox.ui.screens.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.denom.blockforgetoolbox.data.model.AuthorizationState
import com.denom.blockforgetoolbox.data.model.ConnectionState
import com.denom.blockforgetoolbox.data.model.IntegrationStatus
import com.denom.blockforgetoolbox.domain.usecase.ConnectBridgeUseCase
import com.denom.blockforgetoolbox.domain.usecase.DisconnectBridgeUseCase
import com.denom.blockforgetoolbox.domain.usecase.ObserveIntegrationStatusUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    observeStatus: ObserveIntegrationStatusUseCase,
    private val connect: ConnectBridgeUseCase,
    private val disconnect: DisconnectBridgeUseCase
) : ViewModel() {

    val status: StateFlow<IntegrationStatus> = observeStatus()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5_000),
            initialValue = IntegrationStatus()
        )

    fun onConnect() = connect()
    fun onDisconnect() = disconnect()
}
