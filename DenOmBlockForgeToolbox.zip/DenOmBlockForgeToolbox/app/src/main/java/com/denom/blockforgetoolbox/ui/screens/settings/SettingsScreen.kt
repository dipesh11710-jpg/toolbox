package com.denom.blockforgetoolbox.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel()
) {
    val endpoint by viewModel.endpoint.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Settings",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = "Bridge endpoint (WebSocket). Default is local loopback used by the Bedrock Script API add-on.",
            style = MaterialTheme.typography.bodyMedium
        )

        OutlinedTextField(
            value = endpoint,
            onValueChange = { viewModel.updateEndpoint(it) },
            label = { Text("WebSocket URL") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Button(onClick = { viewModel.applyEndpoint() }) {
            Text("Apply Endpoint")
        }

        Spacer(Modifier.height(16.dp))

        Text(
            text = "Security notes",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.SemiBold
        )
        Text(
            text = "• No credentials are collected or stored.\n" +
                    "• Authorization is performed entirely by the in-game Script API bridge.\n" +
                    "• The app never invents success responses.\n" +
                    "• Unsupported or unauthorized operations return explicit failure codes.",
            style = MaterialTheme.typography.bodyMedium
        )
    }
}
