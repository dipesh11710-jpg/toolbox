package com.denom.blockforgetoolbox.ui.screens.diagnostics

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.denom.blockforgetoolbox.data.model.IntegrationStatus
import com.denom.blockforgetoolbox.data.model.OperationResult
import com.denom.blockforgetoolbox.data.repository.IntegrationRepository
import com.denom.blockforgetoolbox.domain.capability.Capability
import com.denom.blockforgetoolbox.domain.usecase.ExecuteCapabilityUseCase
import com.denom.blockforgetoolbox.domain.usecase.ObserveIntegrationStatusUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * Provides the integration test path required by the specification:
 *
 * BlockForge → Integration → Capability Handshake → Authorization State
 * → Minecraft Operation → Actual Result
 */
@HiltViewModel
class DiagnosticsViewModel @Inject constructor(
    observeStatus: ObserveIntegrationStatusUseCase,
    private val executeCapability: ExecuteCapabilityUseCase,
    private val repository: IntegrationRepository
) : ViewModel() {

    val status: StateFlow<IntegrationStatus> = observeStatus()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), IntegrationStatus())

    private val _trace = MutableStateFlow<List<String>>(emptyList())
    val trace: StateFlow<List<String>> = _trace.asStateFlow()

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    fun runIntegrationTest() {
        viewModelScope.launch {
            _isRunning.value = true
            val lines = mutableListOf<String>()
            try {
                lines += "BlockForge"
                lines += "     ↓"
                lines += "Integration"

                val s = status.value
                lines += "     ↓"
                lines += "Capability Handshake"
                lines += if (s.connection == com.denom.blockforgetoolbox.data.model.ConnectionState.CONNECTED)
                    "CONNECTED"
                else
                    "NOT_CONNECTED (${s.connection})"

                lines += "     ↓"
                lines += "Authorization State"
                lines += if (s.authorization == com.denom.blockforgetoolbox.data.model.AuthorizationState.AUTHORIZED)
                    "AUTHORIZED"
                else
                    "AUTHORIZED: FALSE (${s.authorization})"

                lines += "     ↓"
                lines += "Minecraft Operation"
                val capability = Capability.MESSAGE_SEND
                lines += "CAPABILITY: ${capability.name}"

                val result: OperationResult = executeCapability(
                    capability,
                    mapOf("message" to "BlockForge integration test ping")
                )

                lines += "REQUEST: ${if (result.success) "ACCEPTED" else "REJECTED"}"
                lines += "     ↓"
                lines += "Actual Result"
                lines += "RESULT: ${result.code}"
                if (result.message.isNotBlank()) {
                    lines += "DETAIL: ${result.message}"
                }
            } catch (e: Exception) {
                lines += "ERROR: ${e.message}"
            } finally {
                _trace.value = lines
                _isRunning.value = false
            }
        }
    }

    fun clearTrace() {
        _trace.value = emptyList()
    }
}
