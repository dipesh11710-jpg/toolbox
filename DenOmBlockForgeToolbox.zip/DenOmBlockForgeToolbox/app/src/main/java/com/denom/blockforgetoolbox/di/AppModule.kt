package com.denom.blockforgetoolbox.di

import com.denom.blockforgetoolbox.data.repository.IntegrationRepository
import com.denom.blockforgetoolbox.integration.bedrock.BedrockBridgeClient
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideBedrockBridgeClient(): BedrockBridgeClient = BedrockBridgeClient()

    @Provides
    @Singleton
    fun provideIntegrationRepository(
        client: BedrockBridgeClient
    ): IntegrationRepository = IntegrationRepository(client)
}
