package com.denom.blockforgetoolbox.ui.screens.diagnostics

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun DiagnosticsScreen(
    viewModel: DiagnosticsViewModel = hiltViewModel()
) {
    val status by viewModel.status.collectAsState()
    val trace by viewModel.trace.collectAsState()
    val isRunning by viewModel.isRunning.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "Diagnostics / Integration Test",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "Runs the required end-to-end path and reports real outcomes. " +
                    "Never fabricates success when authorization or capability is missing.",
            style = MaterialTheme.typography.bodyMedium
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Live Status", fontWeight = FontWeight.SemiBold)
                Text("Connection : ${status.connection}")
                Text("Authorization : ${status.authorization}")
                Text("Bridge : ${status.bridgeVersion ?: "—"}")
                Text("Minecraft : ${status.minecraftVersion ?: "—"}")
                Text("Capabilities : ${status.supportedCapabilities.joinToString()}")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(
                onClick = { viewModel.runIntegrationTest() },
                enabled = !isRunning
            ) {
                Text("Run Integration Test")
            }
            OutlinedButton(
                onClick = { viewModel.clearTrace() },
                enabled = trace.isNotEmpty()
            ) {
                Text("Clear")
            }
        }

        if (isRunning) {
            CircularProgressIndicator()
        }

        if (trace.isNotEmpty()) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Trace", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    trace.forEach { line ->
                        Text(
                            text = line,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                }
            }
        }
    }
}
