package com.denom.blockforgetoolbox.domain

import com.denom.blockforgetoolbox.domain.capability.Capability
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CapabilityTest {

    @Test
    fun fromId_returnsCorrectCapability() {
        val cap = Capability.fromId("player.teleport")
        assertNotNull(cap)
        assertEquals(Capability.PLAYER_TELEPORT, cap)
    }

    @Test
    fun fromId_unknown_returnsNull() {
        assertNull(Capability.fromId("does.not.exist"))
    }

    @Test
    fun allCapabilitiesHaveUniqueIds() {
        val ids = Capability.entries.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
    }
}
