package com.denom.blockforgetoolbox.integration

import com.denom.blockforgetoolbox.data.model.BridgeMessage
import com.denom.blockforgetoolbox.data.model.HandshakeRequest
import com.denom.blockforgetoolbox.data.model.OperationRequest
import com.denom.blockforgetoolbox.integration.protocol.BridgeProtocol
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BridgeProtocolTest {

    @Test
    fun encodeDecode_handshake_roundTrip() {
        val original = BridgeMessage.Handshake(HandshakeRequest())
        val encoded = BridgeProtocol.encode(original)
        val decoded = BridgeProtocol.decode(encoded)
        assertTrue(decoded is BridgeMessage.Handshake)
        val hs = decoded as BridgeMessage.Handshake
        assertEquals("com.denom.blockforgetoolbox", hs.payload.clientId)
        assertEquals(1, hs.payload.protocolVersion)
    }

    @Test
    fun encodeDecode_operation_roundTrip() {
        val original = BridgeMessage.Operation(
            OperationRequest(
                requestId = "req-1",
                capabilityId = "chat.send",
                parameters = mapOf("message" to "hello")
            )
        )
        val encoded = BridgeProtocol.encode(original)
        val decoded = BridgeProtocol.decode(encoded)
        assertTrue(decoded is BridgeMessage.Operation)
        val op = decoded as BridgeMessage.Operation
        assertEquals("req-1", op.payload.requestId)
        assertEquals("chat.send", op.payload.capabilityId)
        assertEquals("hello", op.payload.parameters["message"])
    }
}
