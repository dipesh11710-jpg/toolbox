# Keep serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt

-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Application models
-keep class com.denom.blockforgetoolbox.data.model.** { *; }
-keep class com.denom.blockforgetoolbox.integration.protocol.** { *; }
