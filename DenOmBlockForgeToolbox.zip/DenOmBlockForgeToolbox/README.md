# DenOm BlockForge Toolbox

**Package:** `com.denom.blockforgetoolbox`  
**Version:** 1.0.0 (versionCode 1)  
**Min SDK:** 26 **Target / Compile SDK:** 34

Complete, buildable Android Studio project that acts as a companion toolbox for Minecraft Bedrock Edition. It performs a real capability handshake with a Bedrock Script API behavior pack and never fabricates success responses.

## Project layout

```
DenOmBlockForgeToolbox/
├── app/                          # Android application module
│   ├── build.gradle.kts
│   └── src/main/java/com/denom/blockforgetoolbox/
│       ├── MainActivity.kt
│       ├── BlockForgeApp.kt
│       ├── ui/                   # Compose UI (Home, Toolbox, Diagnostics, Settings)
│       ├── domain/               # Capabilities + use cases
│       ├── data/                 # Models + repository
│       ├── integration/          # WebSocket bridge client + protocol
│       └── di/                   # Hilt module
├── bedrock-addon/                # Complete Bedrock behavior + resource packs
│   ├── behavior_packs/DenOmBlockForgeBP/
│   └── resource_packs/DenOmBlockForgeRP/
├── build.gradle.kts
├── settings.gradle.kts
└── gradle.properties
```

## Build instructions (external environment required)

APK BUILD ENVIRONMENT UNAVAILABLE in the current sandbox (no Android SDK / Android Gradle Plugin toolchain).

On a machine with Android Studio / Android SDK:

```bash
cd DenOmBlockForgeToolbox

# Optional: create local.properties with sdk.dir=...
# echo "sdk.dir=/path/to/Android/Sdk" > local.properties

./gradlew :app:assembleDebug          # or assembleRelease
# Output: app/build/outputs/apk/debug/app-debug.apk
```

Release (unsigned if no signingConfig is supplied):

```bash
./gradlew :app:assembleRelease
```

Expected artifact names:

- Debug: `app-debug.apk` (applicationId suffix `.debug`)
- Release: `app-release-unsigned.apk` (or signed if you add a signingConfig)

## Integration test path

Diagnostics screen → **Run Integration Test** produces a live trace of the form:

```
BlockForge
     ↓
Integration
     ↓
Capability Handshake
CONNECTED
     ↓
Authorization State
AUTHORIZED
     ↓
Minecraft Operation
CAPABILITY: MESSAGE_SEND
REQUEST: ACCEPTED
     ↓
Actual Result
RESULT: SUCCESS
```

or, when unauthorized:

```
...
AUTHORIZED: FALSE
CAPABILITY: PLAYER_TELEPORT
REQUEST: REJECTED
RESULT: PERMISSION_DENIED
```

## Security guarantees

- No credentials collected or stored.
- Authorization is performed exclusively by the in-game Script API bridge.
- Unsupported / unauthorized operations return explicit failure codes (`UNSUPPORTED`, `PERMISSION_DENIED`, `NOT_CONNECTED`, …).
- No placeholder `TODO()` / `NotImplementedError` implementations for user-facing actions.

## License

Provided as a complete reference implementation for the DenOm BlockForge Toolbox specification.
